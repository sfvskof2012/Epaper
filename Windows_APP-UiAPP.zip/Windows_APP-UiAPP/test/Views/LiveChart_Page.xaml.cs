using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ZstdSharp.Unsafe;
using Microsoft.Maui.Controls;
using test.Services;
using MongoDB.Driver;
using MongoDB.Bson;

namespace test.Views;

public partial class LiveChart_Page : ContentPage
{
    public LiveChart_Page()
    {
        InitializeComponent();
    }
}

public partial class MainPageVM : ObservableObject
{
    static IMongoClient client;
    static IMongoDatabase database;
    static IMongoCollection<BsonDocument> collection;

    [ObservableProperty]
    public ISeries[] testSeries;

    [ObservableProperty]
    public List<Axis> xAxes;

    [ObservableProperty]
    public Axis[] yAxes;

    private Dictionary<string, int> dayOfWeekCounts;


    public static void MongoDBServer()  //��Ʈw���A��
    {
        MongoServices.Initialize();
        client = MongoServices.GetClient();
        database = MongoServices.GetDatabase();
        collection = MongoServices.GetCollection();
    }

    public MainPageVM()
    {
        MongoDBServer();
        collection = database.GetCollection<BsonDocument>("reservation_record");
        int x = 1;

        dayOfWeekCounts = new Dictionary<string, int>
        {
            { "�P���@", 0 },
            { "�P���G", 0 },
            { "�P���T", 0 },
            { "�P���|", 0 },
            { "�P����", 0 },
        };

        // �q MongoDB ���˯����
        var filter = Builders<BsonDocument>.Filter.Empty;
        var documents = collection.Find(filter).ToList();

        // ��s dayOfWeekCounts �r��
        foreach (var document in documents)
        {
            // �ˬd�O�_�s�b reserveDayOfWeek
            if (document.TryGetValue("reserveDayOfWeek", out BsonValue reserveDayOfWeekValue))
            {
                string reserveDayOfWeek = reserveDayOfWeekValue.AsString;

                // �ˬd�r�夤�O�_�]�t�ӬP���X
                if (dayOfWeekCounts.ContainsKey(reserveDayOfWeek))
                {
                    // ��s�����P���X���w�q�ƶq
                    dayOfWeekCounts[reserveDayOfWeek]++;
                }
                else
                {
                    // �B�z�������P���X
                    Console.WriteLine($"�������P���X: {reserveDayOfWeek}");
                }
            }
        }


        TestSeries = new ISeries[]
        {
            new LineSeries<int>
            {
                Values = dayOfWeekCounts.Values.ToArray(),
                Fill = null
            }
        };

        XAxes = new List<Axis>
        {
            new Axis
            {
                Name = "Date",
                NameTextSize = 24,
                // Use the labels property to define named labels.
                Labels = new string[] { "Mon", "Thu", "Wed", "Thr", "Fri" },
                TextSize = 24,
  

            }    
        };

        YAxes = new Axis[]
        {
            new Axis
            {
                Name="Number of reservations",
                NameTextSize = 24,
                TextSize=24,
                
            }
        };
    }
}