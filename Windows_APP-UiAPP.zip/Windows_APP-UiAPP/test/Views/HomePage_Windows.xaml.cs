﻿using MongoDB.Bson;
using MongoDB.Driver;
using test.Models;
using test.ViewModels;
using test.Services;
using System.Diagnostics;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;

namespace test.Views;

public partial class HomePage_Windows : ContentPage
{
    private bool isTransitioning = false;
    private Button selectBuildButton = null;
    private Button selectClassrmButton = null;
    private List<Border> selectedButtons = new List<Border>();
    static IMongoClient client;
    static IMongoDatabase database;
    static IMongoCollection<BsonDocument> collection;

    HomePageVM_Windows vm;
    public HomePage_Windows()
    {
        InitializeComponent();
        vm = new HomePageVM_Windows();
        BindingContext = vm;
    }

    private void SetLoading(ActivityIndicator loading, bool isLoading) //讀取動畫
    {
        loading.IsRunning = isLoading;
        loading.IsVisible = isLoading;
    }
    protected override async void OnAppearing()
    {
        base.OnAppearing();
        isTransitioning = true;
        MongoDBServer();
        isTransitioning = false;
        await Task.CompletedTask;
    }

    public static void MongoDBServer()  //資料庫伺服器
    {
        MongoServices.Initialize();
        client = MongoServices.GetClient();
        database = MongoServices.GetDatabase();
        collection = MongoServices.GetCollection();
    }


    public async void ToolbarMove(VisualElement layout, Border border, string logoSource = "logo.png", int logoWidth = 50, int logoHeight = 80, Color frameColor = null)
    {
        if (isTransitioning) return;
        isTransitioning = true;

        if (frameColor == null)
        {
            frameColor = Colors.White;
        }

        // 關閉其他 Layout 和設置透明度
        CloseMove(layout);

        if (layout.Opacity == 0)
        {
            // 執行顯示 Layout 的動畫
            await AnimateShowLayout(layout, border, logoSource, logoWidth, logoHeight, frameColor);
        }
        else if (layout.Opacity == 1)
        {
            // 執行隱藏 Layout 的動畫
            await AnimateHideLayout(layout, border, logoSource, logoHeight);
        }

        isTransitioning = false;
    }

    private async void CloseMove(VisualElement layout)
    {
        SearchBar_Layout.IsVisible = false;
        MyFavorite_Layout.IsVisible = false;
        Setting_Layout.IsVisible = false;
        LineChart_Layout.IsVisible = false;
        layout.IsVisible = true;

        if (layout == SearchBar_Layout)
        {
            MyFavorite_Layout.Opacity = 0;
            Setting_Layout.Opacity = 0;
            LineChart_Layout.Opacity = 0;
        }
        else if (layout == MyFavorite_Layout)
        {
            SearchBar_Layout.Opacity = 0;
            Setting_Layout.Opacity = 0;
            LineChart_Layout.Opacity = 0;
        }
        else if (layout == Setting_Layout)
        {
            SearchBar_Layout.Opacity = 0;
            MyFavorite_Layout.Opacity = 0;
            LineChart_Layout.Opacity = 0;
        } else if (layout == LineChart_Layout)
        {
            SearchBar_Layout.Opacity = 0;
            MyFavorite_Layout.Opacity = 0;
            Setting_Layout.Opacity = 0;
        }
        await Task.CompletedTask;
    }

    private async Task AnimateShowLayout(VisualElement layout, Border border, string logoSource, int logoWidth, int logoHeight, Color frameColor)
    {
        await Task.WhenAll(
            logo.FadeTo(0, 250),
            Spacer_Plate.TranslateTo(-110, 0, 250),
            divider.TranslateTo(75, 0, 250)
        );

        logo.Source = logoSource;
        logo.WidthRequest = logoWidth;
        logo.HeightRequest = logoHeight;
        await logo.FadeTo(1, 250);

        border.Stroke = frameColor;
        await Task.Delay(250);
        await divider.TranslateTo(330, 0, 250);
        layout.IsEnabled = true;
        await layout.FadeTo(1, 250);
    }

    private async Task AnimateHideLayout(VisualElement layout, Border border, string logoSource, int logoHeight)
    {
        SelectClassRoom.IsVisible = false;
        TestMVVM.IsVisible = false;
        HomePage.IsVisible = true;

        await Task.WhenAll(
            divider.TranslateTo(75, 0, 250),
            layout.FadeTo(0, 250)
        );


        layout.IsEnabled = false;
        await logo.FadeTo(0, 250);
        logo.Source = "epaperlogo.png";
        logo.WidthRequest = 200;
        logo.HeightRequest = logoHeight;
        border.Stroke = Colors.Black;
        await Task.Delay(250);

        await Task.WhenAll(
            Spacer_Plate.TranslateTo(0, 0, 250),
            divider.TranslateTo(330, 0, 250),
            logo.FadeTo(1, 250)
        );
        vm.HomePageTap();
        HomeFrame.Stroke = Colors.White;
    }

    private async void SetHomePage(Border border,
        string logoSource = "logo.png", int logoWidth = 70, int logoHeight = 80, //首頁
        Color frameColor = null)
    {
        if (isTransitioning) return;

        SelectClassRoom.IsVisible = false;
        TestMVVM.IsVisible = false;
        HomePage.IsVisible = true;

        VisualElement layout = null;
        if (HomeFrame.Stroke is SolidColorBrush solidColorBrush)
        {
            if (solidColorBrush.Color == Colors.White) return;

        }
        isTransitioning = true;
        if (border == null)
            border = HomeFrame;
        if (frameColor == null)
            frameColor = Colors.White;

        if (SearchBar_Layout.IsVisible == true)
            layout = SearchBar_Layout;
        if (MyFavorite_Layout.IsVisible == true)
            layout = MyFavorite_Layout;
        if (Setting_Layout.IsVisible == true)
            layout = Setting_Layout;
        if (LineChart_Layout.IsVisible == true)
            layout = LineChart_Layout;


        await Task.WhenAll(
            divider.TranslateTo(75, 0, 250),
            layout.FadeTo(0, 250)
        );
        layout.IsVisible = false;
        layout.Opacity = 0;
        await logo.FadeTo(0, 250);
        logo.Source = "epaperlogo.png";
        logo.WidthRequest = 200;
        logo.HeightRequest = logoHeight;
        border.Stroke = Colors.Black;
        await Task.Delay(250);
        await Task.WhenAll(
            Spacer_Plate.TranslateTo(0, 0, 250),
            divider.TranslateTo(330, 0, 250),
            logo.FadeTo(1, 250)
        );
        vm.HomePageTap();
        HomeFrame.Stroke = Colors.White;
        isTransitioning = false;
    }

    private void SetAllFrameToBlack(Border border)           //設定所有Border的Stroke為黑色
    {
        if (isTransitioning) return;
        if (border != HomeFrame)
            HomeFrame.Stroke = Colors.Black;
        if (border != SearchFrame)
            SearchFrame.Stroke = Colors.Black;
        if (border != MyFavoriteFrame)
            MyFavoriteFrame.Stroke = Colors.Black;
        if (border != SettingFrame)
            SettingFrame.Stroke = Colors.Black;
        if (border != LineChartFrame)
            LineChartFrame.Stroke = Colors.Black;
        UserInfoFrame.Stroke = Colors.Black;
    }

    private void HomePage_Tapped(object sender, TappedEventArgs e)
    {
        if (isTransitioning) return;
        SetAllFrameToBlack(HomeFrame);
        SetHomePage(HomeFrame);
    }

    public void SearchPage_Tapped(object sender, TappedEventArgs e)
    {
        if (isTransitioning) return;
        if (SelectClassRoom.IsVisible == false)
        {
            HomePage.IsVisible = false;
            TestMVVM.IsVisible = false;
            SelectClassRoom.IsVisible = true;
        }
        else
        {
            SelectClassRoom.IsVisible = false;
        }
        SetAllFrameToBlack(SearchFrame);
        ToolbarMove(SearchBar_Layout, SearchFrame);
    }

    private void MyFavoritePage_Tapped(object sender, TappedEventArgs e)
    {
        if (isTransitioning) return;
        SetAllFrameToBlack(MyFavoriteFrame);
        ToolbarMove(MyFavorite_Layout, MyFavoriteFrame);
    }

    private void SettingPage_Tapped(object sender, TappedEventArgs e)
    {
        if (isTransitioning) return;
        SetAllFrameToBlack(SettingFrame);
        ToolbarMove(Setting_Layout, SettingFrame);
    }

    private async void LineChart_Tapped(object sender, TappedEventArgs e)
    {
        Debug.WriteLine("OK");
        await Navigation.PushAsync(new LiveChart_Page());
    }

    private void UserInfo_Tapped(object sender, TappedEventArgs e)
    {

    }

    private async void SearchMyFavotiteClicked(object sender, EventArgs e) //MyFavorite裡的SearchBar的按鈕
    {
        SetLoading(MyFavoriteloading, true);
        await Task.Delay(1000);
        SetLoading(MyFavoriteloading, false);
    }

    private void SelectBuildClicked(object sender, EventArgs e)
    {
        if (sender is Button Buildbtn)
        {
            Buildbtn.BackgroundColor = Color.FromArgb("#9D9D9D");   //按下會變色
            if (selectBuildButton != null && selectBuildButton != Buildbtn) //按下不同按鈕將之前變色的按鈕顏色變回來
            {
                selectBuildButton.BackgroundColor = Color.FromArgb("#2E2E2E");
            }
            selectBuildButton = Buildbtn;
        }
    }

    private void SelectClassRMClicked(object sender, EventArgs e)
    {
        SelectClassRoom.IsVisible = false;
        TestMVVM.IsVisible = true;
    }

    private void SelectCourseTapped(object sender, TappedEventArgs e)
    {

        if (sender is Border SelectCourseBorder)
        {
            var label = SelectCourseBorder.FindByName<Label>("TableTextLabel");
            string firstFiveCharacters = label.Text?.Substring(0, Math.Min(label.Text.Length, 5));
            if (firstFiveCharacters == "Empty")
            {
                if (SelectCourseBorder.BackgroundColor.Equals(Color.FromArgb("#2E2E2E")))
                {
                    SelectCourseBorder.BackgroundColor = Color.FromArgb("#9D9D9D");
                }
                else if (SelectCourseBorder.BackgroundColor.Equals(Color.FromArgb("#9D9D9D")))
                {
                    SelectCourseBorder.BackgroundColor = Color.FromArgb("#2E2E2E");
                }
            }

        }

    }

}


