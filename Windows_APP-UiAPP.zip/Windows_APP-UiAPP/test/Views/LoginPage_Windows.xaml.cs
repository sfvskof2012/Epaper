using test.ViewModels;

namespace test.Views;

public partial class LoginPage_Windows : ContentPage
{
    LoginPageVM_Windows vm;
    public LoginPage_Windows()
    {
        InitializeComponent();
        vm = new LoginPageVM_Windows();
        BindingContext = vm;
    }
}