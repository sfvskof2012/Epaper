﻿using test.Views;

namespace test
{
    public partial class AppShell:Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.Window.Height = 900;
            this.Window.MinimumWidth = 1920;
            this.Window.MinimumHeight = 900;
            this.Window.MaximumWidth = 1920;
            this.Window.MaximumHeight = 1080;
        }
    }
}


