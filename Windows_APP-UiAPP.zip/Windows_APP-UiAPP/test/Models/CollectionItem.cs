using CommunityToolkit.Mvvm.Input;
using System.Windows.Input;

namespace test.Models;

public class CollectionItem
{
    public string Title { get; set; }
    public string Description { get; set; }
}

public class KioskItem
{
    public string PictureAds { get; set; }

    public ICommand PictureAdsCommand { get; set; }
}

public class NumberItem
{
    public int NumberAds {  get; set; }

    public string NumberTitle { get; set; }
}
public class ClassNumberItem
{
    public string ClassNumberText { get; set; }
    public string ClassTimeText { get; set; }
}

public class TableItem
{
   public string TableText { get; set; } 

   public ICommand SelectCourse { get; set; }

   public object SelectCourseNumbers {  get; set; }

    public Color TableBorder { get; set; }

}
