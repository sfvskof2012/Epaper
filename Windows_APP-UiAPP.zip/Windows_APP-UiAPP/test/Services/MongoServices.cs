﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test.Services
{
    public partial class MongoServices
    {

        private const string ConnectUri = "mongodb+srv://sfvskof2012:4a9g0120@atlascluster.kzam66q.mongodb.net/?retryWrites=true&w=majority";
        private static IMongoClient _client;
        private static IMongoDatabase _database;
        private static IMongoCollection<BsonDocument> _collection;

        public static void Initialize()
        {
            _client = new MongoClient(ConnectUri);
            _database = _client.GetDatabase("School");
            _collection = _database.GetCollection<BsonDocument>("classroom");
        }

        public static IMongoClient GetClient()
        {
            return _client;
        }

        public static IMongoDatabase GetDatabase()
        {
            return _database;
        }

        public static IMongoCollection<BsonDocument> GetCollection()
        {
            return _collection;
        }
    }
}
