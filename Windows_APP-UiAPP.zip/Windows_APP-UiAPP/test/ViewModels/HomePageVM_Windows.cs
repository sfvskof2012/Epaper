using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using test.Models;
using test.Services;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Dynamic;
using test.Views;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.DependencyInjection;
using System.ComponentModel;
using Microsoft.Maui.Controls;
using System.Windows.Input;
using MauistringCommand = Microsoft.Maui.Controls.Command<string>;
using System.Diagnostics;
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using test.ViewModels;

namespace test.ViewModels
{

    public partial class HomePageVM_Windows : BaseVM
    {
        static IMongoClient client;
        static IMongoDatabase database;
        static IMongoCollection<BsonDocument> collection;
        private string class_id;
        private string classroom;
        private bool isTransitioning = false;
        private ObservableCollection<string> selectedClasses = new ObservableCollection<string>();
        private ObservableCollection<string> ReservedClasses = new ObservableCollection<string>();

        [ObservableProperty]
        private bool lineChartVisible = false;

        [ObservableProperty]
        private string pictureAds;

        [ObservableProperty]
        private ICommand pictureAdsCommand;

        [ObservableProperty]
        private KioskItem currentItem;
        private int _currentIndex = 0;
        private Timer _timer;

        [ObservableProperty]
        private int position;

        public static void MongoDBServer()  //��Ʈw���A��
        {
            MongoServices.Initialize();
            client = MongoServices.GetClient();
            database = MongoServices.GetDatabase();
            collection = MongoServices.GetCollection();
        }

        public async Task NewCollection()
        {
            try
            {
                var items = new ObservableCollection<CollectionItem>();

                for (int i = 1; i <= 30; i++)
                {
                    items.Add(new CollectionItem
                    {
                        Title = $"Title {i}",
                        Description = $"Description {i}"
                    });
                }
                SearchSource = new ObservableCollection<CollectionItem>(items);
            }
            catch (Exception ex)
            {
                await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
            }

        }

        [ObservableProperty]
        private ObservableCollection<NumberItem> numberCV = new ObservableCollection<NumberItem>();
        [ObservableProperty]
        private string numberAds;
        [ObservableProperty]
        private string numberTitle;
        public void NewAds()
        {
            var item = new ObservableCollection<NumberItem>();

            Dictionary<int, string> titleMapping = new Dictionary<int, string>
            {
                { 1, "�i�p�عq�l�j�j�|�U�Ǵ��b����]��/IT��ߥͩ۶ҭp�e" },
                { 2, "�i�x�~�j�n�O��ޤj�Ǹ�T�u�{�t�۸u�M���Юv(113�~8��_�u)" },
                { 3, "�Τ@��T�yIT��s your turn ! 2024��T�H�~�Ӥh��߭p�e�z�۶Ҭ��ʲ{���i�}" },
                { 4, "�i���~�x�~�j�n�Z��ޥx�n�t" },
                { 5, "��u�t�ۼ��ܽ��w��t�Ͱѥ[ �u�t�ͦ^�Q�a�v���ʡA�q�ж�g���ʳ��W��" },
            };

            for (int i = 1; i <= 5; i++)
            {
                NumberCV.Add(new NumberItem
                {
                    NumberAds = i,
                    NumberTitle = titleMapping[i]
                });
            }
        }

        public HomePageVM_Windows()
        {
            MongoDBServer();
            string identity = Identity;
            Debug.WriteLine("����" + identity);
            if(identity == "admin")
                LineChartVisible = true;
            createKiosk();
            NewAds();
            StartAutoPlay();
            SearchSource = new ObservableCollection<CollectionItem>();
        }

        [ObservableProperty]
        ObservableCollection<KioskItem> kiosk;


        private void StartAutoPlay()
        {
            _timer = new Timer(TimerCallback, null, TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(3));
        }
        private void TimerCallback(object state)
        {
            // ������U�@�Ӥ���
            _currentIndex = (_currentIndex + 1) % Kiosk.Count;
            CurrentItem = Kiosk[_currentIndex];
        }
        private void createKiosk()
        {
            Kiosk = new ObservableCollection<KioskItem> {
                 new KioskItem { PictureAds = "pic_1.png", PictureAdsCommand = new Command(TestButtonCommand) },
                 new KioskItem { PictureAds = "pic_2.png", PictureAdsCommand = new Command(TestButtonCommand) },
                 new KioskItem { PictureAds = "pic_3.png", PictureAdsCommand = new Command(TestButtonCommand) }
            };

        }

        [RelayCommand]
        public async Task HomePageTap()
        {
            _timer = new Timer(TimerCallback, null, TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(3));
        }

        [RelayCommand]
        public async Task SearchPageTap()
        {
            if (isTransitioning == true) return;
            isTransitioning = true;
            BuildButtons = new ObservableCollection<Button>();
            ClassRoomButtons = new ObservableCollection<Button>();
            _timer.Change(Timeout.Infinite, Timeout.Infinite);
            await createbuildbtn();
            await Task.Delay(1000);
            isTransitioning = false;
            await Task.CompletedTask;
        }

        [RelayCommand]
        private async Task LeftKiosk()
        {
            _currentIndex = (_currentIndex - 1 + Kiosk.Count) % Kiosk.Count;
            CurrentItem = Kiosk[_currentIndex];
            _timer.Change(TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(3));
            await Task.CompletedTask;
        }

        [RelayCommand]
        private async Task RightKiosk()
        {
            _currentIndex = (_currentIndex + 1) % Kiosk.Count;
            CurrentItem = Kiosk[_currentIndex];
            _timer.Change(TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(3));
            await Task.CompletedTask;
        }

        [RelayCommand]
        public async Task SearchResultTap()
        {
            IsBusy = true;

            await NewCollection();
            await Task.Delay(1000);
            await Task.CompletedTask;

            IsBusy = false;
        }

        private async Task createbuildbtn()
        {

            try
            {
                collection = database.GetCollection<BsonDocument>("classroom");
                var results = collection.Find(new BsonDocument()).ToList();
                if (results != null)
                {
                    var geberatedBuilding = new HashSet<string>();
                    geberatedBuilding.Clear();
                    foreach (var result in results)
                    {
                        string building = result.GetValue("building").ToString();
                        if (geberatedBuilding.Contains(building)) continue;
                        var button = new Button
                        {
                            Text = building,
                            Command = new MauistringCommand(SelectClassroomBtn),
                            CommandParameter = building
                        };
                        BuildButtons.Add(button);
                        geberatedBuilding.Add(building);
                    }
                }
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
            }
        }


        private async void SelectClassroomBtn(string selectbuild)
        {
            try
            {
                var filter = Builders<BsonDocument>.Filter.Eq("building", selectbuild);
                var classrooms = collection.Find(filter).ToList();
                classrooms = classrooms.OrderBy(classrm => classrm.GetValue("name").AsString).ToList();
                ClassRoomButtons = new ObservableCollection<Button>();

                foreach (var classroom in classrooms)
                {
                    var classroomname = classroom.GetValue("name").AsString;
                    var id = classroom["_id"].AsObjectId.ToString();

                    var classbtn = new Button
                    {
                        Text = classroomname,
                        Command = new Microsoft.Maui.Controls.Command<string>(ClassTable),
                        CommandParameter = classroomname + ";" + id
                    };
                    ClassRoomButtons.Add(classbtn);
                }
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
            }
        }

        public static string ConvertToChineseNumber(int number) //�N�Ʀr�ഫ������Ʀr
        {
            string[] chinesesNumbers = { "�@", "�G", "�T", "�|", "��", "��", "�C", "�K", "�E" };

            if (number >= 1 && number <= 9)
            {
                return chinesesNumbers[number - 1];
            }
            else
            {
                return number.ToString();
            }
        }


        private async Task CreateDay()
        {
            DayNumber = new ObservableCollection<Label>();
            //DayNumber.Add(new Label
            //{
            //    Text = "�ɶ� / ���",
            //});

            for (int i = 1; i <= 5; i++)
            {
                DayNumber.Add(new Label
                {
                    Text = "�P��" + ConvertToChineseNumber(i),
                });
            }
            await Task.CompletedTask;

        }


        private async Task CreateClassnumber()
        {
            string[] StartTimes = { "08:10", "09:10", "10:10", "11:10", "12:50", "13:50", "14:50", "15:50", "16:50" };
            string[] EndTimes = { "09:00", "10:00", "11:00", "12:00", "13:40", "14:40", "15:40", "16:40", "17:40" };

            ClassNumber = new ObservableCollection<ClassNumberItem>();

            for (int i = 0; i < 9; i++)
            {
                ClassNumber.Add(new ClassNumberItem
                {
                    ClassNumberText = "�� " + ConvertToChineseNumber(i + 1) + " �`",
                    ClassTimeText = StartTimes[i] + " ~ " + EndTimes[i]

                });
            }

            await Task.CompletedTask;
        }

        private Dictionary<string, ObservableCollection<TableItem>> ClassTableDictionary;
        private async void ClassTable(string para)
        {
            string[] paras = para.Split(';');  //���Ѹ��
            classroom = paras[0];
            class_id = paras[1];
            selectedClasses.Clear();
            ReservedClasses.Clear();

            ClassTableDictionary = new Dictionary<string, ObservableCollection<TableItem>>
            {
                { "1",  ClassTableNumber_Mon = new ObservableCollection<TableItem>() },
                { "2",  ClassTableNumber_Thu = new ObservableCollection<TableItem>() },
                { "3", ClassTableNumber_Wed = new ObservableCollection<TableItem>() },
                { "4", ClassTableNumber_Thr = new ObservableCollection<TableItem>() },
                { "5", ClassTableNumber_Fri = new ObservableCollection<TableItem>() }
            };

            collection = database.GetCollection<BsonDocument>("timetable");
            var filter = Builders<BsonDocument>.Filter.Eq("classroom_id", new ObjectId(class_id));
            var table = collection.Find(filter).ToList();
            await CreateDay();
            await CreateClassnumber();
            if (table != null)
            {
                ClassRoomText = classroom;

                var sortedTable = table.OrderBy(item => item["course_schedule"]["date"].AsString)
                               .ThenBy(item => item["course_schedule"]["class"].AsString);

                foreach (var item in sortedTable)
                {
                    var time_courseDoc = item["course_schedule"];
                    var course = item["course"].AsString;
                    var classname = item["classname"].AsString;
                    var instructor = item["instructor"].AsString;
                    var date = time_courseDoc["date"].AsString;
                    var dayclass = time_courseDoc["class"].AsString;
                    var status = item["status"];


                    if (ClassTableDictionary.TryGetValue(date, out ObservableCollection<TableItem> classTable))
                    {
                        if (status <= 60)
                        {
                            if (status != 60)
                            {
                                ReservedClasses.Add(date + ";" + dayclass);
                                classTable.Add(new TableItem
                                {
                                    TableText = course + "\n" + "\n" + status,
                                    SelectCourse = new MauistringCommand(SelectedReserver),
                                    SelectCourseNumbers = date + ";" + dayclass,
                                    TableBorder = Colors.GreenYellow
                                });
                            }
                            else
                            {
                                classTable.Add(new TableItem
                                {
                                    TableText = course + "\n" + "\n" + status,
                                    SelectCourse = new MauistringCommand(SelectedReserver),
                                    SelectCourseNumbers = date + ";" + dayclass,
                                    TableBorder = Colors.DarkOrange
                                });
                            }
                        }
                        else if (status == "Class Time")
                        {
                            classTable.Add(new TableItem
                            {
                                TableText = course + "\n" + classname + "\n" + instructor + "\n" + status,
                                TableBorder = Color.FromArgb("#9D9D9D")
                                //SelectCourse = new MauistringCommand(Reserver)
                            });
                        }
                    }
                }
            }
            await Task.CompletedTask;
        }


        private async void SelectedReserver(string classroomnumber)
        {

            if (selectedClasses.Contains(classroomnumber))
            {
                selectedClasses.Remove(classroomnumber);
            }
            else
            {
                selectedClasses.Add(classroomnumber);
            }

            foreach (var classroom in selectedClasses)
            {
                Debug.Write(classroom + " ");
            }

            Debug.WriteLine("");
            await Task.CompletedTask;
        }

        [RelayCommand]
        private async Task ReserverClassroom()
        {
            var filter = Builders<BsonDocument>.Filter.Eq("classroom_id", new ObjectId(class_id));
            var table = collection.Find(filter).ToList();
            if (table != null)
            {
                var sortedTable = table.OrderBy(item => item["course_schedule"]["date"].AsString)
                              .ThenBy(item => item["course_schedule"]["class"].AsString);

                foreach (var selected in selectedClasses)
                {
                    string[] temp = selected.Split(';');
                    string day = temp[0];
                    string day_class = temp[1];
                    var updatefilter = sortedTable.FirstOrDefault(item => item["course_schedule"]["date"] == day &&
                                                                          item["course_schedule"]["class"] == day_class);
                    if (updatefilter != null)
                    {
                        var currentStatus = Convert.ToInt32(updatefilter["status"]);
                        var newStatus = currentStatus - 1;
                        Debug.Write(updatefilter + "\n");
                        var update = Builders<BsonDocument>.Update
                            .Set("status", newStatus);
                        collection.UpdateOne(updatefilter, update);
                    }
                }
            }
            ClassTable(classroom + ";" + class_id);
            await Task.CompletedTask;
        }

        [RelayCommand]
        private async Task CancelReserver()
        {
            var filter = Builders<BsonDocument>.Filter.Eq("classroom_id", new ObjectId(class_id));
            var table = collection.Find(filter).ToList();
            if (table != null)
            {
                var sortedTable = table.OrderBy(item => item["course_schedule"]["date"].AsString)
                              .ThenBy(item => item["course_schedule"]["class"].AsString);

                foreach (var selected in ReservedClasses)
                {
                    string[] temp = selected.Split(';');
                    string day = temp[0];
                    string day_class = temp[1];
                    var updatefilter = sortedTable.FirstOrDefault(item => item["course_schedule"]["date"] == day &&
                                                                          item["course_schedule"]["class"] == day_class);
                    if (updatefilter != null)
                    {
                        Debug.Write(updatefilter + "\n");
                        var update = Builders<BsonDocument>.Update
                            .Set("status", 60);
                        collection.UpdateOne(updatefilter, update);
                    }
                }
            }
            ClassTable(classroom + ";" + class_id);
            await Task.CompletedTask;
        }
    
        private async void TestButtonCommand()
        {
            Debug.WriteLine("Test OK!");
        }
    }
}