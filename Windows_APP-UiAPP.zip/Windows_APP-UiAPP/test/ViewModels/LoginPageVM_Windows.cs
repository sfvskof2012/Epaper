using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using test.Views;
using test.Models;
using test.Services;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Dynamic;
using System.Diagnostics;


namespace test.ViewModels
{
    public partial class LoginPageVM_Windows : BaseVM
    {
        static IMongoClient client;
        static IMongoDatabase database;
        static IMongoCollection<BsonDocument> collection;

        [ObservableProperty]
        private string accountText = "admin";

        [ObservableProperty]
        private string passwordText = "1234";


        public static void MongoDBServer()  //��Ʈw���A��
        {
            MongoServices.Initialize();
            client = MongoServices.GetClient();
            database = MongoServices.GetDatabase();
            collection = MongoServices.GetCollection();
        }

        [RelayCommand]
        public async Task Login()
        {
            MongoDBServer();
            IsBusy = true;
            try
            {
                database = client.GetDatabase("test_user");
                collection = database.GetCollection<BsonDocument>("users");
                var filter = Builders<BsonDocument>.Filter.Eq("user", AccountText) & Builders<BsonDocument>.Filter.Eq("password", PasswordText);
                var results = await collection.Find(filter).FirstOrDefaultAsync();
                if (results == null)
                {
                    await Application.Current.MainPage.DisplayAlert("���~", "�b���αK�X���~", "OK");
                }
                else
                {
                    Identity = results.GetValue("identity").AsString;
                    Debug.WriteLine("�ǰe"+ Identity);
                    await Task.Delay(100);
                    await Shell.Current.GoToAsync("//Home");
                    //await Navigation.PushAsync(new HomePage());
                }
            }
            catch (Exception ex)
            {
                await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
            }
            IsBusy = false;
        }
    }
};