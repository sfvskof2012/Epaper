using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Input;
using test.Models;

namespace test.ViewModels
{
    public partial class BaseVM : ObservableObject
    {

        private static string _identity;

        public static string Identity
        {
            get { return _identity; }
            set { _identity = value; }
        }

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(isNotBusy))]

        bool isBusy;
        public bool isNotBusy => !IsBusy;

        [ObservableProperty]
        ObservableCollection<CollectionItem> searchSource;

        [ObservableProperty]
        string title;

        [ObservableProperty]
        string description;

        [ObservableProperty]
        ObservableCollection<Button> buildButtons;


        [ObservableProperty]
        string buildButtonText;

        [ObservableProperty]
        private string selectBuildButton;

        [ObservableProperty]
        ObservableCollection<Button> classRoomButtons;

        [ObservableProperty]
        private string selectClassrmButton;

        [ObservableProperty]
        private string classRoomText;

        [ObservableProperty]
        ObservableCollection<Label> dayNumber;

        [ObservableProperty]
        public string days;

        [ObservableProperty]
        public string dayCol;

        [ObservableProperty]
        ObservableCollection<ClassNumberItem> classNumber;

        [ObservableProperty]
        private string classNumberText;

        [ObservableProperty]
        private string classTimeText;

        [ObservableProperty]
        private string tableText;

        [ObservableProperty]
        private ICommand selectCourse;

        [ObservableProperty]
        private object selectCourseNumbers;

        [ObservableProperty]
        private Color tableBorder;


        [ObservableProperty]
        ObservableCollection<TableItem> classTableNumber_Mon;

        [ObservableProperty]
        ObservableCollection<TableItem> classTableNumber_Thu;

        [ObservableProperty]
        ObservableCollection<TableItem> classTableNumber_Wed;

        [ObservableProperty]
        ObservableCollection<TableItem> classTableNumber_Thr;

        [ObservableProperty]
        ObservableCollection<TableItem> classTableNumber_Fri;

    }
}
